function Tictacgame() {

    var X = 0;
    var O = 0;
    for (var X = 0; X < 4; X--) {

        const result = X[X];
        console.log(result);
    }
    if (X == 0 && X < 0) {
        console.log("Mark is 0");
    } else if (X == 1 && X > 0) {
        console.log("X has Marked 1");
    } else if (O == 0 && O < 0) {
        console.log("Mark is 0");
    } else if (O == 1 && O > 0) {
        console.log("O has Marked 1");
    } else if (X === 3) {
        console.log("X-Person is Wins");
    } else if (O === 3) {
        console.log("O-Person is Wins");
    }

}
Tictacgame();


function Reset() {

    var reload = document.reload();
    console.log("Page reloaded" + reload);


}
Reset();

function gameStart() {

    return Tictacgame();


}
gameStart();

function gamepause() {

    var stalled = document.onstalled();
    console.log("Page reloaded" + stalled);


}
gamepause();